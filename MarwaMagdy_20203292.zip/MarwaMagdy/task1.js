//Question 1
/* 
let num= prompt("Enter Number: ");
if (num%2==0){
    console.log("Number is Even");
}
else{
    console.log("Number is odd");
}
*/





//question 2
/* 
for(let i=1; i<=100; i++)
{
    if(i % 3 === 0 && i % 5){
        console.log("fizzBuzz")
    }
    else if (i % 3 === 0){
        console.log("fizz")
    }else if(i % 5 === 0){
        console.log("Buzz")
    }else{
        console.log(i)
    }
}
*/






//question 3
/*
let word = prompt("Enter a word:");

let reversedWord = "";
for (var i = word.length - 1; i >= 0; i--) {
  reversedWord += word[i];
}

console.log(`The reversed word is: ${reversedWord}`);

*/






//question 4
/*
const PI=3.14;
let radius=prompt("Enter the Radius of circle: ");
let area=PI * radius^2;
console.log(`Area of circle= ${area}`);
let circum=2*PI*radius;
console.log(`Circumference of circle= ${circum}`);

*/





//question 5
/*
let num1=Number(prompt("Enter first number: "));
let num2=Number(prompt("Enter second number: "));

if (num1===50||num2===50||num1+num2===50){
    console.log("true");
}
else{
    console.log("false");
}
*/





//question 6
/*
let num1=Number(prompt("Enter first number: "));
let num2=Number(prompt("Enter second number: "));

if ((num1 < 0 && num2 > 0) || (num1 > 0 && num2 < 0)) {
    console.log("true");
  } else {
    console.log("false");
  }

*/





//question 7
/*
let num=Number(prompt("Enter a number: "));

if (num % 5 === 0 && num>0) {
    console.log("Multiple of 5");
  } else if (num % 8 === 0 && num>0) {
    console.log("Multiple of 8");
  } else {
    console.log("Not a multiple of 5 or 8");
  }

*/





//question 8
/*
let num1=Number(prompt("Enter the first number: "));
let num2=Number(prompt("Enter the second number: "));
let num3=Number(prompt("Enter the third number: "));

if(num1>num2&&num1>num3){
  console.log(`The largest number is ${num1}`)
}
else if(num2>1&&num2>num3){
  console.log(`The largest number is ${num2}`)
}
else if(num3>num1&&num3>num2){
  console.log(`The largest number is ${num3}`)
}
*/




//question 9
/*
let sum = 0;

for (let i = 1; i <= 10; i++) {
  sum += i;
}

console.log(`The sum is: ${sum}`);
*/





//question 10
/*
let rows = 5; 
for (let i = 1; i <= rows; i++) {
  var str = '';

  for (let j = 1; j <= i; j++) {
    str += '*';
  }

  console.log(str);
}
*/





//question 11
/*
let num =Number(prompt("Enter a number: "));
 if (num<0)
{
  console.log("Number is negative")
}
else if(num>=0){
  console.log("Number is positive")
}
*/





//question 12
/*let arr = [];

for (let i = 0; i < 10; i++) {
  arr[i] = prompt(`Enter element ${i}:`);
}

console.log("The elements in the array are:");
for (let i = 0; i < arr.length; i++) {
  console.log(`Element ${i}: ${arr[i]}`);
}
*/





//question 13
/*
let num1=Number(prompt("Enter first number: "));
let num2=Number(prompt("Enter second number: "));

console.log(`Sum of the two numbers= ${num1+num2}`);
*/





//question 14
/*
let num = parseInt(prompt("Enter the number:"));
let factorial = 1;
for (let i = 1; i <= num; i++) {
  factorial *= i;
}
console.log(`The factorial of  ${num} is: ${factorial}`);
*/






//question 15
/*
let num1=Number(prompt("Enter the first number: "));
let num2=Number(prompt("Enter the second number: "));
let calc=prompt("Enter the type of operation(+,-,*,/):");

switch(calc){
  case '+':
    console.log(`${num1}+${num2}= ${num1+num2}`);
    break;
  case '-':
    console.log(`${num1}-${num2}= ${num1-num2}`);
    break;
  case '*':
    console.log(`${num1}*${num2}= ${num1*num2}`);
    break;
  case '/':
    console.log(`${num1}/${num2}= ${num1/num2}`);
    break;
  default:
    console.log("error");
    break;
}
*/
